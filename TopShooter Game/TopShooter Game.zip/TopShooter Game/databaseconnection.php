<?php
   $connection =mysqli_connect("localhost","root","","topshooter" )
or die ('Could not connect to mysql');
/*allows the page connect to the database*/
    ?>