private bool check() {
    bool dead = false;
    if (dead == true) {
    dead = true;
    return deathscreen
    }
    else if (playertotal == 1) {
    return deathscreen
    }
    else{ 
    dead = false
    return dead
    }
}