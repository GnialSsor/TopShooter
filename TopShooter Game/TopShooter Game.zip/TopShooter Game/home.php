<?php
    include("navigationbar.php"); /* This will include the navigation bar which contains css to the page */
    include("databaseconnection.php"); /* This will include the database connection */




/*Creates button to access game */
echo '<div class="container">
<a href=gameMap.php class="btn btn-primary">Play</a>
</div>'
    ;?>

<html>

<body>
    <h1>Welcome to TopShooter</h1>
    
    <p>"Disclaimer: Suitable for 12+"</p>
</body>
</html>