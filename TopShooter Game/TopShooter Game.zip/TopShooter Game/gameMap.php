<!DOCTYPE html>
<!-- Created by Ross Laing -->

<html>

<head>
	<title>Top Shooter</title>
		<!-- Website Meta Tags -->
		
		<!-- Reference
			 Title: HTML <meta> tag // Author: W3Schools
			 URL: https://www.w3schools.com/tags/tag_meta.asp -->
		<meta charset="UTF-8">
		<meta name="description" content="Mass Multiplayer Shooting Game">
		<meta name="keywords" content="Shooter, Game, Pixel, Baylle Royale ">
		<meta name="author" content="Top Shooter">
		
		<!-- External Stylesheet -->
		<link rel="stylesheet" href="topshooter.css">

	<!-- Reference 
		 Title: JavaScript - Move Object with Arrow Keys using JavaScript Function // Author: Include Help 
		 URL: https://www.includehelp.com/code-snippets/move-object-with-arrow-keys-using-javascript-function.aspx -->
	
	<!-- This piece of javascript will allow the character sprite, controlled by the user,
	to move about the screen. The user will user the arrow keys on thier keyboard to do so.-->
	<script type="text/javascript">
			
			var objImage= null;
			//initialises the sprite and positions it on the screen, using localised CSS.
			function init(){
				objImage=document.getElementById("yellowSprite");				
				objImage.style.position='relative';
				objImage.style.left='0px';
				objImage.style.top='0px';
			}
			
			//This function will call others function, dependant on the key press (arrow keys).
			//Keycodes:
			//37: left arrow key
			//38: up arrow key
			//39: right arrow key
			//40: down arrow key
			function getKeyAndMove(e){				
				var key_code=e.which||e.keyCode;
				switch(key_code){
					case 37:
						moveLeft();
						break;
					case 38:
						moveUp();
						break;
					case 39:
						moveRight();
						break;
					case 40:
						moveDown();
						break;						
				}
			}
			function moveLeft(){
				//set the speed of the image when it moves
				objImage.style.left=parseInt(objImage.style.left)-5 +'px';
			}
			function moveUp(){
				//set the speed of the image when it moves
				objImage.style.top=parseInt(objImage.style.top)-5 +'px';
			}
			function moveRight(){
				//set the speed of the image when it moves
				objImage.style.left=parseInt(objImage.style.left)+5 +'px';
			}
			function moveDown(){
				//set the speed of the image when it moves
				objImage.style.top=parseInt(objImage.style.top)+5 +'px';
			}
			window.onload=init;
	</script>
		
	<script>
//Insert shooting code here

	</script>
		
		
	<script>
//Insert collision code here

	</script>

	<script>
//Insert player death code here

	</script>
	
</head>

<!-- The onKeyDown event looks for any action that take place in the chatacter movement function.
	 If any arrow key buttons have been pressed, then the movement will be shown within the body.
	 Which holds the users character. -->
<body onkeydown='getKeyAndMove(event)'>
<!-- Start background music as soon as page is opened -->
	<bgsound src = "/snd/bensound-epic.mp3"/>
<!-- Shows character to user -->
	<img id="yellowSprite"></img>
</body>


<script>
<!-- Creates a timer for HUD -->
<!-- Reference: https://stackoverflow.com/questions/46220382/javascript-count-up-timer -->
var countDownDate = localStorage.getItem('startDate');
if (countDownDate) {
    countDownDate = new Date(countDownDate);
} else {
    countDownDate = new Date();
    localStorage.setItem('startDate', countDownDate);
}
// Update the count down every 1 second
var x = setInterval(function() {

    //Gets the date and time of when the program was opened
    var now = new Date().getTime();

    //Calculates the difference between current time and the time the program was opened
    var distance = now - countDownDate.getTime();

    // Time calculations minutes and seconds, to be displayed on the HUD
    var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
    var seconds = Math.floor((distance % (1000 * 60)) / 1000);

    //Displays the time on the HUD using the id 'timer'
    document.getElementById("timer").innerHTML = "Time: " + minutes + ":" + seconds;
}, 1000);

</script>

<script>
// Points Score to be displayed on HUD
<!-- Reference: https://stackoverflow.com/questions/46220382/javascript-count-up-timer -->
var countDownDate = localStorage.getItem('startDate');
if (countDownDate) {
    countDownDate = new Date(countDownDate);
} else {
    countDownDate = new Date();
    localStorage.setItem('startDate', countDownDate);
}

var x = setInterval(function() {

    // Get todays date and time
    var now = new Date().getTime();

    // Find the distance between now an the count down date
    var distance = now - countDownDate.getTime();

    // Score calculation. Every second the user survives. They gain 2 points.
    var points = Math.floor((distance % (1000 * 60)) / 500);

    //Displays the score on the HUD using the id 'score'
    document.getElementById("score").innerHTML = "Score: " + points;
}, 1000);

// FIX NEEDED: Score resets every 60 seconds

</script>

<footer>
<!-- Heads Up Display. providing information to the user. Placed within the footer, to all the HUD to be displayed underneath the map-->
	<table>
		<thead>
			<tr>
<!-- Displays the timer -->
				<th><p id="timer"></p></th>
<!-- Displays the user's score-->
				<th><p id="score"></th>
<!-- Displays an 'Exit Button' to the user. Once clicked the user will be taken back to the home page.-->
				<th><button type="button" onclick="document.location='home.php'">Exit Game</button></th>
			</tr>
		</thead>
	</table>
</footer>

</html>
